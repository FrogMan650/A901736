; This is a branching macro test program.
; Tests various forms of conditional statements.
; It demonstrates various forms of conditional statements.
M0
G10 P144 R9 ; Set roundoff to 9 significant digits.

; IF [<expression>] <true_block>
X0
IF [1.0 EQ 1.0] X1 ; Should move to 1.0
M0
IF [1.0 NE 1.0] X2 ; Should *not* move to 2.0
M0

; IF [<expression>] <true_block> ELSE <false_block>
X0
IF [1.0 EQ 1.0] X1 ELSE X2 ; Should move to 1.0
M0
IF [1.0 NE 1.0] X1 ELSE X2 ; Should move to 2.0
M0

; IF <expression> THEN <true_block>
X0
IF 1.0 EQ 1.0 THEN X1 ; Should move to 1.0
M0
IF 1.0 NE 1.0 THEN X2 ; Should *not* move to 2.0
M0

; IF [<expression>] THEN <true_block>
X0
IF [1.0 EQ 1.0] THEN X1 ; Should move to 1.0
M0
IF [1.0 NE 1.0] THEN X2 ; Should *not* move to 2.0
M0

; IF <expression> THEN <true_block> ELSE <false_block>
X0
IF 1.0 EQ 1.0 THEN X1 ELSE X2 ; Should move to 1.0
M0
IF 1.0 NE 1.0 THEN X1 ELSE X2 ; Should move to 2.0
M0

; IF [<expression>] THEN <true_block> ELSE <false_block>
X0
IF [1.0 EQ 1.0] THEN X1 ELSE X2 ; Should move to 1.0
M0
IF [1.0 NE 1.0] THEN X1 ELSE X2 ; Should move to 2.0
M0

; IF [<expression1>] IF [<expression2>] <true_block>
; Equivalent to:
; IF [[<expression1>] AND [<expression2>]] <true_block>
; but with conditional evaluation of expression2
X0
#101 = 2
; Should move to X1.1
IF [#101 GT 0] IF [[20 / #101] GT 1] X[9.9 / [[20 / #101] - 1]]
M0

; IF <expression> THEN <block1> ELSE IF <expression2> THEN <block2> ELSE <block3>
X0
; Should move to X1
IF 1.0 EQ 1.0 THEN X1 ELSE IF 1.0 EQ 1.0 THEN X2 ELSE X3
M0
; Should move to X2
IF 1.0 NE 1.0 THEN X1 ELSE IF 2.0 EQ 2.0 THEN X2 ELSE X3
M0
; Should move to X3
IF 1.0 NE 1.0 THEN X1 ELSE IF 2.0 NE 2.0 THEN X2 ELSE X3
M0

;********************************************************************
; Repeat same tests as above except with no spaces
; IF[<expression>]<true_block>
X0
IF[1.0EQ1.0]X1; Should move to 1.0
M0
IF[1.0NE1.0]X2; Should *not* move to 2.0
M0

; IF[<expression>]<true_block>ELSE<false_block>
X0
IF[1.0EQ1.0]X1ELSEX2; Should move to 1.0
M0
IF[1.0NE1.0]X1ELSEX2; Should move to 2.0
M0

; IF<expression>THEN<true_block>
X0
IF1.0EQ1.0THENX1; Should move to 1.0
M0
IF1.0NE1.0THENX2; Should *not* move to 2.0
M0

; IF[<expression>]THEN<true_block>
X0
IF[1.0EQ1.0]THENX1; Should move to 1.0
M0
IF[1.0NE1.0]THENX2; Should *not* move to 2.0
M0

; IF<expression>THEN<true_block>ELSE<false_block>
X0
IF1.0EQ1.0THENX1ELSEX2; Should move to 1.0
M0
IF1.0NE1.0THENX1ELSEX2; Should move to 2.0
M0

; IF[<expression>]THEN<true_block>ELSE<false_block>
X0
IF[1.0EQ1.0]THENX1ELSEX2; Should move to 1.0
M0
IF[1.0NE1.0]THENX1ELSEX2; Should move to 2.0
M0

; IF[<expression1>]IF[<expression2>]<true_block>
; Equivalent to:
; IF[[<expression1>]AND[<expression2>]]<true_block>
; but with conditional evaluation of expression2
X0
#101 = 2
; Should move to X1.1
IF[#101GT0]IF[[20/#101]GT1]X[9.9/[[20/#101]-1]]
M0

; IF<expression>THEN<block1>ELSEIF<expression2>THEN<block2>ELSE<block3>
X0
; Should move to X1
IF1.0EQ1.0THENX1ELSEIF1.0EQ1.0THENX2ELSEX3
M0
; Should move to X2
IF1.0NE1.0THENX1ELSEIF2.0EQ2.0THENX2ELSEX3
M0
; Should move to X3
IF1.0NE1.0THENX1ELSEIF2.0NE2.0THENX2ELSEX3
M0

;********************************************************************
; IF <expression> <true_block> ; Error! IF requires brackets or THEN
M0                             ; to limit scope of expression.
X0
IF 1.0 EQ 1.0 X1