; This is the Ballbar Program

g21
g90m5g17
m109/1/2
g1x-151.5y0z0f1000
m0
g1x-150y0
g2x-150y0i150j0
g2x-150y0i150j0
g1x-151.5y0
g4p3
g1x-150y0
g3x-150y0i150j0
g3x-150y0i150j0
g1x-151.5y0
m108/1/2
m30
