;/////////////////////////////////////////////////////////////////
;// Filename:         setup_probe_artic_head.cnc
;// Author:           Lee Johnston
;// Date:             February 12th 2009
;// Last Modified:    April 15th 2013
;// Description:      Setup Probe on Articulated Head machine. Sets Center of rotation to tip of probe...
;// Usage:            G65 "setup_probe_artic_head.cnc"
;// Inputs:           None
;// Outputs:          Sets Parameter #119
;//
;// Prompts:          Prompt User to Jog to position
;// $Header: svn://192.168.0.222/cnc11/trunk/FinalDiscImage/LayoutMill/cncm/ncfiles/setup_probe_artic_head.cnc 4546 2015-03-17 20:42:55Z keith $
;/////////////////////////////////////////////////////////////////

; Variables Used:

; # Define section
 #30010 = 3 ;

 #103 = 0
 #102 = -45
 
; capture P166 value:
#101 = [#9166]

; Reset P166 to 1281 for the test:
G10 P166 r[1281]

N100 ; Main
G54 ; Assumes Articulated Head Machine uses G54
M25 ; Move Z-Axis Up
if #50001;
G43 H[#9012] D[#9012] ; Set tool height offset. Check #H

; Manual Probing Section
N110 ; Probe First point

 #30010 = 0
M225 #30010 "To setup Tools we must determine the distance from the\n Reference Tool Tip to the B-Axis center of rotation\nThis program will assist in doing this\nPress Cycle Start to Continue"
M225 #30010 "To determine this we must probe the TT-1/TT-2 at B0\nFollowed by probing the TT-1/TT-2 at B-45\nEnsure Probe is in the Spindle\nPress Cycle Start to position the B-Axis"
M125 /B0 P#9011 F100
M200 "Jog Probe into position above the TT-1/TT-2\nPress Cycle Start to Probe TT-1/TT-2"

 #106 = [#5043] ; save the start poing

M115 /Z[[#106]-[#9016]] P#9011 F#9014 ; Probe Z- for Surface
G1 Z#106 F#9393
M115 /Z[[#106]-[#9016]] P#9011 F#9394 ; Probe Z- for Surface

 #30111 = #24303

if #50001;

N120
; Probe Second Position
M225 #30010 "B-Axis will now be positioned to B-45\nPress Cycle Start to position B-Axis"

G1 Z[[#106]+[4]] F100 ; move 4 units above the start point

M125 /B[#102] P#9011 F50
M200 "Jog Probe into position above the TT-1/TT-2\nPress Cycle Start to probe TT-1/TT-2"

if #50001
 #106 = [#5043]

M115 /Z[[#106]-[#9016]] P#9011 F#9014 ; Probe Z- for Surface
G1 Z#106 F#9393
M115 /Z[[#106]-[#9016]] P#9011 F#9394 ; Probe Z- for Surface

 #30112 = #24303

M25

N400 ; Calculate distance between tip of tool and the center of rotation:
if #50001;

 #104 = [[#30112] - [#30111]]
M225 #100 "measured: %.5f" #104
 #107 = [[#104]/[1-[cos[#102]]]]
M225 #100 "calc: %.5f" #107
 #108 = [#11000]
M225 #100 "dia:: %.5f" #108
 #109 = [[#108]/2]
M225 #100 "radius: %.5f" #109
 #105 = [[#107] - [#109]]
M225 #100 "final: %.5f" #105
M225 #30010 "The distance found is: %.5f\nPress Cycle Start to save to Parameters" #105

 G10 P119 r[#105]
 
 ; Reset P166 to original value:
G10 P166 r[#101]

M99
; END
