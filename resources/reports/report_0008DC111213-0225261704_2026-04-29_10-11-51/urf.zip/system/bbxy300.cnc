; This is the Ballbar Program

g21
g90m5g17
m109/1/2
g1x-301.5y0z0f2000
m0
g1x-300y0
g2x-300y0i300j0
g2x-300y0i300j0
g1x-301.5y0
g4p3
g1x-300y0
g3x-300y0i300j0
g3x-300y0i300j0
g1x-301.5y0
m108/1/2
m30
