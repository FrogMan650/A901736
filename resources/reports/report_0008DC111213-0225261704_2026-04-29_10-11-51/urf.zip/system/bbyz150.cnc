; Ball bar YZ plane 180 / 360 degree.
; Dynamic 180 / 360 degree data capture
; 150 mm
;
g21
g90m5g17
m109/1/2
g1x0y-151.5z0f1000
g19				; Circular interp. Plane Selection YZ
m0
g1y-150z0
g2y-150z0j150k0
g2y-150z0j150k0
g1y-151.5z0
g4p3
g1y-150z0
g3y-150z0j150k0
g3y-150z0j150k0
g1y-151.5z0
m30
