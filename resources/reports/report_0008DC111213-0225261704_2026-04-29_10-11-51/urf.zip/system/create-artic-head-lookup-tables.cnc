;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; File:    create-artic-head-lookup-tables.cnc
; Purpose: Move the B axis through it's travel forward and
;          backward recording B axis scale readings.
; Update:  10-Jan-2020 KSD Support 20 or 22-bit scale encoder
; Output:  The file "c:\cncm\artic-head-lut.txt"
; Notes:   This program is executed from the CNC software
;          Artic Head Calibrate menu.
;          CNC software then parses the output and generates a tilt.tab, which is 
;          used by CNC software to generate motor counts to send to the MPU when
;          screw comp is on. The MPU also uses tilt.tab for scale correction 
;          when scales are turned on.
;
; $Header: svn://192.168.0.222/cnc11/trunk/FinalDiscImage/LayoutMill/cncm/ncfiles/create-artic-head-lookup-tables.cnc 4466 2015-02-03 20:19:00Z keith $
;
; Copyright 2015-2020 Centroid Corp. Howard, PA         
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
G20  ; Select inch units

#104 = 0.5    ; The increment between recorded positions
#111 = 0      ; Set to 1 for bench testing

; #103 is the number of scale counts per revolution
#103 = (#27505 * 360.0  + 0.5) 
#103 = #103 - (#103 % 1.0)
if [#103 == 2^20 || #103 == 2^22] then goto 3

; Error, Scale Counts not 20 or 22 bit
m225 #100 "Error: Scale Encoder Counts/Rev not 20 or 22 bit"

goto 10000

N3

; Open (with overwrite) the file used to record the data
; This file will be read by CNC11 to generate the tilt.tab file
M120 "#400\artic-head-lut.txt"



; Write out the file version. This should be the first line written as  
; it is used to specify the format of the rest of the file. The line
; should start with a number that can be parsed as a double. The remainder
; of the line is not used.
; Note: We place two places on the header lines so that the output is
;       compatible with the plot.exe program.
M223 "  1.0  // File version\n" 

; The format for file version 1.0:
; Second line is a string containing date information.
; Third line is the motor count creeping to level from negative side
; Fourth line is the motor count creeping to level from the positive side
; Fifth line is a label line for use with the plot program
; Each line thereafter contains these five fields separated by whitespace:
; Field 1 Commanded B axis motor position in local coordinates (degrees)
; Field 2 The B axis motor encoder count 
; Field 3 The B axis scale encoder count
; Field 4 The B axis scale encoder count converted to degrees
; Field 5 Difference (absolute error) between Field 4 and Field 1
;
; A typical line of output is:
; 57.0000      69935    3912699  57.002478   0.002478
;
; The data is recorded starting at the home position and proceeds from
; there to the opposite side of travel and then back. Commanded positions
; are in whole degrees except at either end where there is a move to the
; travel limit.
;

; Record the date 
m123L1; 
M127


#100 = -0.01
N5
; Creep to B0 from the negative side
  G90 G1 B-1.00 F30 
  G90 G1 B#100 F30
  G4 P1
  if #50001  
  if #27405 < #25205 then goto 10
  #100 = #100 * 2
  if #100 <= -1.0 then goto 30
  goto 5
  
N10
  G91 G1 M128/B L-1
if #111 then G91 G1 M128/U L-1
  if #50001
  if #27405 < #25205 then goto 10
; Record motor counts and scale counts
m223 "  %.0f // Creep to level from negative side (motor encoder counts)\n" #27305 

#100 = 0.01
N15 
; Creep to B0 from the positive side
  G90 G1 B+1.00 F30
  G90 G1 B#100 F30
  G4 P1
  if #50001  
  if #27405 > #25205 then goto 20
  #100 = #100 * 2
  if #100 >= 1.0 then goto 30
  goto 15
  
N20
  G91 G1 M128/B L1
if #111 then G91 G1 M128/U L1

  if #50001
  if #27405 > #25205 then goto 20
; Record motor counts and scale counts
m223 "  %.0f // Creep to level from positive side (motor encoder counts)\n" #27305 
  goto 50
  
N30 ; Error
 #100 = 0
 m225 #100 "Error: tolerance exceeded on creep to zero"
 #error Tolerance exceeded on creep procedure

N50

; Output label line for plot program
m223 "commanded      motor      scale      angle      error\n"  

  if #50001
; Record articulating head scale encoder counts at B zero (level)
  #100 = #25205
; Local Coordinate Negative Travel  (Travel_minus - B_wcs)
  #120 = #23505 - #2900
; Local Coordinate Plus Travel Limit (Travel_Plus - B_wcs)
  #121 = #23605 - #2900
; Drop fractional parts to give limits in whole integer degrees
  #120 = #120 - #120 % 1.0
  #121 = #121 - #121 % 1.0

N100 

; Move to initial starting position with lash taken up. 
; Because there can be a small non-zero plus travel limit,
; we start at the off-switch position and move to travel limit.
  G90 G1 B[#121] F120
if #111 then G90 G1 U[#121] F120
  M92/B L1
  
; Set position at plus travel limit, make move, and record a line of data
  #105 = [#23605 - #2900]
  G90 G1 B#105 F30
if #111 then G90 G1 U#105 F30  
  G4 P1
  if #50001
  #101 = 360 * (#27405 - #100) / #103
  #102 = #101 - #105
  M223 "%9.4f %10.0f %10.0f %10.6f %10.6f\n" #105 #27305 #27405 #101 #102  

; Set whole encoder count position near plus travel limit.
  #105 = #121
N110
; make move and record a line of data
  G90 G1 B#105 F30
if #111 then G90 G1 U#105 F30  
  G4 P1
  if #50001
  #101 = 360 * (#27405 - #100) / #103
  #102 = #101 - #105
  M223 "%9.4f %10.0f %10.0f %10.6f %10.6f\n" #105 #27305 #27405 #101 #102

  ; decrement position and loop if end not reached
  #105 = #105 - #104
  if #105 >= #120 then goto 110

; Set position at minus travel limit, make move, and record a line of data
  #105 = [#23505 - #2900]
  G90 G1 B#105 F30
if #111 then G90 G1 U#105 F30  
  G4 P1
  if #50001
  #101 = 360 * (#27405 - #100) / #103
  #102 = #101 - #105
  M223 "%9.4f %10.0f %10.0f %10.6f %10.6f\n" #105 #27305 #27405 #101 #102

; Set whole encoder count position near minus travel limit.
  #105 = #120
N140
; make move and record a line of data
  G90 G1 B#105 F30
if #111 then G90 G1 U#105 F30  
  G4 P1  
  if #50001
  #101 = 360 * (#27405 - #100) / #103
  #102 = #101 - #105
  M223 "%9.4f %10.0f %10.0f %10.6f %10.6f\n" #105 #27305 #27405 #101 #102

; increment position and loop if end not reached
  #105 = #105 + #104
  if #105 <= #121 then goto 140

; Set position at plus travel limit, make move, and record a line of data
  #105 =  [#23605 - #2900] 
  G90 G1 B#105 F30 
if #111 then G90 G1 U#105 F30
  G4 P1
  if #50001
  #101 = 360 * (#27405 - #100) / #103
  #102 = #101 - #105
  M223 "%9.4f %10.0f %10.0f %10.6f %10.6f\n" #105 #27305 #27405 #101 #102
   
N9999 ; the end 
; Communicate to CNC11 no error. CNC11 will set #32000 = 1.0
; before running this job. If some other error (parsing, E-stop, etc.)
; happens before this line, the calling code in CNC11 will know.
  #32000 = 0 
  
N10000
  