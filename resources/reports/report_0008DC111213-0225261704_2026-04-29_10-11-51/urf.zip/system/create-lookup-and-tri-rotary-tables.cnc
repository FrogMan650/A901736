;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Filename:   create-lookup-and-tri-rotary-tables.cnc
; Purpose:    Create lookup tables for an articulated head machine with a 
;             BiSS encoder mounted to it
; Programmer: John Popovich, Keith Dennison
; Date:       09-Jun-2014
; Requires:   CNC11 v3.13R12 or better
;
; Notes:      Assumes the "B" triangular rotary axis is the 5th one and
;             the scale menu settings for the "B" axis have the input
;             set correctly for the BiSS scale encoder.
;             
;             This program creates a file called tilt.tab.new  
;             to prevent accidental overwriting of tilt.tab.
; 
;             See instructions below.
;
; Copyright 2011-2014  Centroid Corporation, Howard, PA 16841
;
; $Header: svn://192.168.0.222/cnc11/trunk/FinalDiscImage/LayoutMill/cncm/ncfiles/create-lookup-and-tri-rotary-tables.cnc 4346 2014-09-08 16:34:35Z keith $
;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Instructions
; ------------
;  1) Make a report.
;  2) Delete the tilt.tab file, turn off tables for the B axis and disable scales.
;  3) Power off and then power up. You may want to park the machine beforehand.
;  4) Before homing, enable B axis scales. After homing, run this program.
;  5) Copy tilt.tab.new to tilt.tab.uncomp.
;  6) Copy tilt_plot.txt to tilt_plot.txt.uncomp.
;  7) Rename tilt.tab.new to tilt.tab.
;  8) Turn on tables. Power off and then power up again. 
;  9) After homing, run this program.
; 10) Copy tilt.tab.new to tilt.tab.comp
; 11) Copy tilt_plot.txt to tilt_plot.txt.comp
;
; Notes: Steps 5, 6, and 9-11 are not strictly necessary, 
;        but are helpful to view a before and after picture.
;        In particular, viewing/plotting the tilt_plot.uncomp
;        and tilt_plot.comp will allow one to see what effect 
;        the tables are having. Note that you will not see 
;        much effect from scales until the axis ballscrew undergoes
;        thermal expansion.
;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Constants
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
#101 = 30           ; B axis feedrate
#102 = 1            ; Angle Increment (alway positive)
#104 = [2^22]/360   ; BiSS Counts/Degree
#106 = 92           ; B axis m91/m92 homing direction
#107 = .0001        ; zero tolerance
#108 = 0.5          ; dwell time
#109 = -1;          ; start direction

#301 = "c:/cncm/tilt.tab.new"  ; output file
#302 = "c:/cncm/tilt_plot.txt" ; plot output file

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Variables
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
#110 = 0     ; Current degree
#111 = 0     ; Biss Zero position
#112 = 0     ; Current BiSS Reading
#113 = 0     ; B axis current position (counts)
#114 = 26205 ; travel limit variable
#115 = 0     ; 0 = foward table, 1 == reverse table
#116 = 0     ; number of points collected
#117 = 0     ; angular error
#118 = 0     ; angular error
#119 = 0     ; b start angle
#121 = 0     ; BiSS encoder reading
#122 = 0     ; B move to position
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Program Start
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
 G64 OFF
#102 = #102 * #109 ; set the increment based on the start direction
M120 "#301" ; Open file for writing to
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; File Header
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
M223 "TILT LOOKUP TABLE\n"
M223 "********** FORWARD ***********\n" 

M120 "#302" ; open plot file
M223 "  B axis calibration Plot\n  "
m127
M223 "CommandedAngle Error\n"
M121 "#301" ; Open file for writing to

; the forward table is away from home

G90      ; set absolute positioning mode
G1 F#101 ; set the feedrate

#114 = 26205 ; travel limit variable
if [#102 > 0] then #114 = 26305
B#[#114] ; Start at B travel limit
m#106/b  ; move to the limit switch and back
m26/b    ; set b home
; record the biss "Zero" position
g4 p#108
if #50001
; zero = direction * BiSS absolute position
#111 = #27405 ; read the B axis scale 
#119 = #5045  ; record the starting angle
#110 = #119
#114 = 26205 ; travel limit variable
if [#102 < 0] then #114 = 26305

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Main Loop
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
N100 

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Read Biss Encoder
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

g4 p#108
if #50001 ; sync
#121 = #27405        ; read the B axis scale encoder (BiSS)
#112 = #121 - #111   ; offset from BiSS zero
#112 = #112/#104     ; convert to degrees
#113 = #23805        ; record the B axis motor encoder position

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Store data in memory or write point to file
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
if #50001 ;sync
; get the angular error
#117 = 0
#118 = 0
#[117+#115] = #112 - #5045 + #119
#118 = #[117+#115]
#120 = #5045 - #119
M121 "#302" ; open plot file
;"CommandedAngle AngularError"
M223 "%f %f\n" #120 #118
M121 "#301" ; Open file for writing to

if [#102 < 0] then GOTO 125
; Moving positive write the point to the file now
M223 "%.15f %.0f %0.f %f\n" #112 #113 #121 #122  
goto 130 ; goto end record point

N125 ; store point into memory
#[29000 + #116] = #112 ; store measured angle
#[29001 + #116] = #113 ; store B axis encoder position
#[29002 + #116] = #121 ; store BiSS encoder position
#[29003 + #116] = #122 ; store B move to position

#116 = #116+4 ; increment the data pointer
N130 ; end record point

;if #116 >= 40 then goto 200 ; test for lash check
if [[abs[#110 -#[#114]]] < #107] then GOTO 200 ; if we are at the travel limit we are done

#110 = #110 + #102  ; angle = angle + angle_increment

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Limit move
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
if [#102 > 0] then goto 150 ; moving positive
if [#110 < #[#114]] then #110 = #[#114]
goto 160
N150 ; moving positive
if [#110 > #[#114]] then #110 = #[#114]
N160 ; end limit move

B #110      ; Move B to the next angle
#122 = #110
GOTO 100 ; goto record position

N200 
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; End Pass
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
if #50001 ; sync
if [#102 > 0] then goto 300 ; goto check for end if the direction is positive
N250 ; write out data
#116 = #116-4;
; the data must be written to file in reverse order from which it was recorded
if [#116 < 0] then goto 300 ; done writing data goto check for end of program
#112 = #[29000 + #116] ; measured angle
#113 = #[29001 + #116] ; motor encoder
#121 = #[29002 + #116] ; BiSS encoder
#122 = #[29003 + #116] ; B move to position
; write the point to the file
M223 "%.15f %.0f %0.f %f\n" #112 #113 #121 #122
GOTO 250

N300 ; check for end of program
if #115 == 1 then GOTO 500 ; goto end of program if the reverse flag is set
M223 "********** REVERSE ***********\n" 
#116 = 0 ; reset the memory pointer
#115 = 1 ; set reverse table flag
#102 = -#102 ; reverse the increment
#114 = 26205 ; travel limit variable
if [#102 < 0] then #114 = 26305

;B [#110 + [.01 * -#109]] ; move a little bit to take up lash
GOTO 100 ; do the reverse table


N500 ; end program

