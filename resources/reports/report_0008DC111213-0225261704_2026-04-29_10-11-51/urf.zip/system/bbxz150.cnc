; Ball bar XZ plane 180 / 360 degree.
; Dynamic 180 / 360 degree data capture
; 100 mm
;
g21
g90m5g17
m109/1/2
g1x-151.5y0z0f1000
g18				; Circlar Interp. Plane Selection XZ.
m0
g1x-150z0
g2x-150z0i150k0
g2x-150z0i150k0
g1x-151.5z0
g4p3
g1x-150z0
g3x-150z0i150k0
g3x-150z0i150k0
g1x-151.5z0
m30
