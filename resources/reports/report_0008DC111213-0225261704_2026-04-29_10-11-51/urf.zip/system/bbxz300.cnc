; Ball bar XZ plane 180 / 360 degree.
; Dynamic 180 / 360 degree data capture
; 100 mm
;
g21
g90m5g17
m109/1/2
g1x-301.5y0z0f2000
g18				; Circlar Interp. Plane Selection XZ.
m0
g1x-300z0
g2x-300z0i300k0
g2x-300z0i300k0
g1x-301.5z0
g4p3
g1x-300z0
g3x-300z0i300k0
g3x-300z0i300k0
g1x-301.5z0
m30
