; Ball bar YZ plane 180 / 360 degree.
; Dynamic 180 / 360 degree data capture
; 100 mm
;
g21
g90m5g17
m109/1/2
g1x0y-301.5z0f2000
g19				; Circular interp. Plane Selection YZ
m0
g1y-300z0
g2y-300z0j300k0
g2y-300z0j300k0
g1y-301.5z0
g4p3
g1y-300z0
g3y-300z0j300k0
g3y-300z0j300k0
g1y-301.5z0
m30
